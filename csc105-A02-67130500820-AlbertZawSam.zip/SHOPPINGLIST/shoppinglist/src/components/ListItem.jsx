import { useState } from "react";
import "../styles/ListItem.css";

export default function ListItem({ item, toggleBought, removeItem, editItem }) {
  const [isEditing, setIsEditing] = useState(false);
  const [newText, setNewText] = useState(item.text);

  const handleEdit = () => {
    editItem(item.id, newText);
    setIsEditing(false);
  };

  return (
    <li className={item.bought ? "bought" : ""} onClick={() => toggleBought(item.id)}>
      {isEditing ? (
        <>
          <input
            type="text"
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
          />
          <button onClick={handleEdit}>Save</button>
        </>
      ) : (
        <>
          {item.text}
          <button className="delete" onClick={(e) => { e.stopPropagation(); removeItem(item.id); }}>
            Remove
          </button>
          <button className="edit" onClick={(e) => { e.stopPropagation(); setIsEditing(true); }}>
            Edit
          </button>
        </>
      )}
    </li>
  );
}
