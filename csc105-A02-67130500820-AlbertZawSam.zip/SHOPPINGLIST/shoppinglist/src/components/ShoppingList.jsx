import { useState } from "react";
import InputForm from "./InputForm";
import ListItem from "./ListItem";
import "../styles/ShoppingList.css";

export default function ShoppingList() {
  const [items, setItems] = useState([]);

  const addItem = (text) => {
    setItems([...items, { id: Date.now(), text, bought: false }]);
  };

  const toggleBought = (id) => {
    setItems(
      items.map((item) =>
        item.id === id ? { ...item, bought: !item.bought } : item
      )
    );
  };

  const removeItem = (id) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const editItem = (id, newText) => {
    setItems(
      items.map((item) => (item.id === id ? { ...item, text: newText } : item))
    );
  };

  return (
    <div className="shopping-list">
      <h2>Shopping List</h2>
      <InputForm addItem={addItem} />
      <ul>
        {items.map((item) => (
          <ListItem
            key={item.id}
            item={item}
            toggleBought={toggleBought}
            removeItem={removeItem}
            editItem={editItem}
          /> 
        ))}
        
      </ul>
    </div>
  );
}
