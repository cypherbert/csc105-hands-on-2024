import React from "react";

const DisplayHeader = ({ result }) => {
  return (
    <>
      <div>Simple Calculator</div>
      <div>Result: {result}</div>
    </>
  );
};

export default DisplayHeader;
