import React from "react";

const InputBox = ({ setInput, input }) => {
  return (
    <input
      type="text"
      placeholder="Enter a number"
      value={input}
      onChange={(e) => {
        if (isFinite(e.target.value)) {
          setInput(+e.target.value);
        }
      }}
    />
  );
};

export default InputBox;
