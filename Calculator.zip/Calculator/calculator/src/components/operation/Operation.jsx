import React from "react";

const Operation = ({ input, setResult, setInput }) => {
  const add = function () {
    setResult((r) => r + input);
    setInput("");
  };

  const subtract = function () {
    setResult((r) => r - input);
    setInput("");
  };

  const multiply = function () {
    setResult((r) => r * input);
    setInput("");
  };

  const divide = function () {
    if (input === 0) {
      alert("Can't divide by 0");
      setInput("");
      return;
    }
    setResult((r) => r / input);
    setInput("");
  };

  const clearInput = function () {
    setInput("");
  };

  const clearRest = function () {
    setResult(0);
  };

  return (
    <>
      <div>
        <button onClick={add}>Add</button>
        <button onClick={subtract}>Subtract</button>
        <button onClick={multiply}>Multiply</button>
        <button onClick={divide}>Divide</button>
      </div>
      <div>
        <button onClick={clearInput}>Reset Input</button>
        <button onClick={clearRest}>Reset Result</button>
      </div>
    </>
  );
};

export default Operation;
